<?php
    session_start();
	require_once('../Models/alldb.php');
    if (isset($_GET['admin']))
	{
		header('location:../Views/adminLogin.php');
	}
    if (isset($_GET['customer']))
	{
		header('location:../Views/customerLogin.php');
	}
	if (isset($_GET['reg']))
	{
		header('location:../Views/Registraton.php');
	}

    if (isset($_GET['cusLogin'])) {
		$id = $_GET['id'];
		$pass = $_GET['pass'];
		if (empty($id) || empty($pass)) 
		{
			$_SESSION['error'] = "Please fill the form!";
			header('location: ../Views/customerLogin.php');
		} else {
			if (is_numeric($id)) {
				$result = cusCheck($id, $pass);
				if (mysqli_num_rows($result) == 1) {
					$_SESSION['id'] = $id;
					header('location: ../Views/customerHome.php');
				} else {
					$_SESSION['error'] = "Incorrect login!";
					header('location: ../Views/customerLogin.php');
				}
			}
		}
	}
	
    if (isset($_GET['adLogin'])) {
		$id = $_GET['id'];
		$pass = $_GET['pass'];
		if (empty($id) || empty($pass)) {
			$_SESSION['error'] = "Please fill the form!";
			header('location: ../Views/adminLogin.php');
		} else {
			if (is_numeric($id)) {
				$result = adCheck($id, $pass);
				if (mysqli_num_rows($result) == 1) {
					$_SESSION['id'] = $id;
					header('location: ../Views/adminHome.php');
				} else {
					$_SESSION['error'] = "Incorrect login!";
					header('location: ../Views/adminLogin.php');
				}
			}
		}
	}
	

	if(isset($_POST['Add']))
	{
		$id=$_POST['id'];
		$name=$_POST['name'];
		$pass=$_POST['pass'];
		if (empty($id) || empty($name)|| empty($pass)) {
			$_SESSION['error'] = "Please fill up the form";
			header("location:../views/Registraton.php");
			exit();
			}
			$status = add($id, $name, $pass);
			if ($status) 
			{
				header("location:../views/customerLogin.php");
			} else 
			{
				$_SESSION['succ'] = "Not Inserted";
				header("location:../views/Registraton.php");
			}

		}
				

    if (isset($_GET['request']))
	{
		$name=$_GET['request'];
        $offer=$_GET['offer'][$name];
        update($name, $offer);
        $_SESSION['request']="Requested!";
        header('location:../Views/customerHome.php');
	}
    if (isset($_GET['accept']))
	{
		$name=$_GET['accept'];
        $offer=update1($name);
        $_SESSION['message']="Accepted";
        header('location:../Views/adminHome.php');
	}
    if (isset($_GET['reject']))
	{
		$name=$_GET['reject'];
        $offer=update2($name);
        $_SESSION['message']="Rejected";
        header('location:../Views/adminHome.php');
	}
    if (isset($_GET['logout']))
	{
		unset($_SESSION['name']);
		header('location:../index.php');
	}
?>