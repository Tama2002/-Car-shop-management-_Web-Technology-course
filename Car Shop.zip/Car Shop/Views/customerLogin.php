<?php
    session_start();
  ?>
<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
</head>
<body>
  <form action="../Controllers/logController.php">
    <h1>Customer Login</h1><br><br><br>
    ID: <input type="text" name="id" ><br><br>
    Pass: <input type="password" name="pass" ><br><br><br>
    <button name="cusLogin">Login</button><br><br>
    <button name="reg">Regisration</button><br><br>
    
    

  <?php
    if (isset($_SESSION['error']))
    {
      echo $_SESSION['error'];
      unset($_SESSION['error']);
    }
  ?>
  </form>
</body>
</html>