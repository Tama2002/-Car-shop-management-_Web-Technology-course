<?php
    session_start();
    require_once('../Models/alldb.php');
    $res= data();
    if (empty($_SESSION['name']))
    {
      header('location:../Views/customerLogin.php');
    }
  ?>
<!DOCTYPE html>
<html>
<head>
	<title>Customer Home</title>
</head>
<body>
  <form action="../Controllers/logController.php">
  
  <h1>Customer home page</h1><br><br>  
  <h3>Welcome <?php echo $_SESSION['name']; ?> </h3><br><br>
  <h3>Welcome <?php echo $_SESSION['id']; ?> </h3><br><br>
    
    
    <table border="1">
      <tr>
        <th>Car Name</th>
        <th>Engine Number</th>
         <th>Expected Price</th>
         <th>Offer Price</th>
         <th>Action</th>
      </tr>
    <?php while ($r=$res->fetch_assoc()) { ?>
      <tr>
        <td><?php echo $r['Name']; ?></td>
        <td><?php echo $r['Engine Number']; ?></td>
        <td><?php echo $r['Price']; ?></td>
        
        <td><input type="text" name="offer[<?php echo $r['Name']; ?>]" ></td>

        <td><button name="request" value="<?php echo $r['Name']; ?>">Request</button></td>
      </tr>
    <?php } ?>
    </table>

    <br>
    <button style="name="logout">Logout</button><br><br>
    <?php
    if (isset($_SESSION['request']))
    {
      echo $_SESSION['request'];
      unset($_SESSION['request']);
    }
  ?>
  
  </form>
  
</body>
</html>