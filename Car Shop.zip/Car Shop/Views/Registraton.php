<?php
    session_start();
  ?>
<!DOCTYPE html>
<html>
<head>
	<title>Customer Registration</title>
</head>
<body>
  <form method="post" action="../Controllers/logController.php">
    <h1>Customer Information Input</h1><br><br><br>
    ID: <input type="text" name="id" ><br><br>
    Name: <input type="text" name="name" ><br><br>
    Pass: <input type="password" name="pass" ><br><br><br>
    <button name="Add">Upload</button><br><br>

    
    

  <?php
    if (isset($_SESSION['succ']))
    {
      echo $_SESSION['succ'];
      unset($_SESSION['succ']);
    }

    if (isset($_SESSION['error']))
    {
      echo $_SESSION['error'];
      unset($_SESSION['error']);
    }
  ?>
  </form>
</body>
</html>