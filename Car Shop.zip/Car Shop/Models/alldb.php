<?php
	require_once('db.php');
	function adCheck($id,$pass)
	{
		$con=con();
		$sql="select * from admin where Id='$id' and Pass='$pass'";
		$res=mysqli_query($con, $sql);
		return $res;
	}
    function cusCheck($id,$pass)
	{
		$con=con();
		$sql="select * from customer where Id='$id' and Pass='$pass'";
		$res=mysqli_query($con, $sql);
		return $res;
	}
	function insert($name, $offer)
	{
		$con=con();
		$sql="insert into car values ($offer) where Name='$name'";
		$res=mysqli_query($con, $sql);
	}
	function data()
	{
		$con=con();
		$sql="select * from car";
		$res=mysqli_query($con, $sql);
		return $res;
	}
	
	
	function update($name, $offer)
	{
		$con=con();
		$sql="update car set Offer='$offer' where Name='$name'";
		$res=mysqli_query($con, $sql);
		return $res;
	}
    function update1($name)
	{
		$con=con();
		$sql="update car set Price = Offer, Offer = NULL where Name='$name'";
		$res=mysqli_query($con, $sql);
		return $res;
	}
    function update2($name)
	{
		$con=con();
		$sql="update car set  Offer = NULL where Name='$name'";
		$res=mysqli_query($con, $sql);
		return $res;
	}
    function data1()
	{
		$con=con();
		$sql="SELECT * FROM car WHERE offer IS NOT NULL;";
		$res=mysqli_query($con, $sql);
		return $res;
	}
	function add($id, $name, $pass)
	{
		$con=con();
		$sql="Insert into customer values('$id' , '$name', '$pass') ";
		$res=mysqli_query($con,$sql);
		return $res;

	}

?>