<?php

?>
<!DOCTYPE  html>
<html>
    <head>
        <title>Index</title>
    </head>
    <body>
        <h1>Login</h1>
        <form action="Controllers/logController.php">
            Login as: <br>
            <button name="admin">Admin</button>
            <button name="customer">Customer</button>
        </form>
    </body>
</html>